package Pack;

class Lion extends Animal {
    private int MaxWeight = 550 ;

    public Lion(String name, int age) {
        // Assuming 'Lion' as the default species for this subclass
        super(name, "Lion", age);
    }

    public int getMaxWeight(){
        return MaxWeight;
    }
}
