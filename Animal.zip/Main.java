package Pack;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {


        ArrayList<Animal> animals = new ArrayList<>();
        Map<String, Integer> speciesCount = new HashMap<>();

        int bearIndex = 0;
        int tigerIndex = 0;
        int lionIndex = 0;
        int hyenaIndex = 0;

        String Name = "test";
        String Species = "";
        int Age = 0;

        String filePath = ("C:/Users/ErikL/OneDrive/Desktop/arrivingAnimals.txt");
        File file = new File(filePath);


        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                // Age is in the first element of the array named parts
                String[] parts = line.split(", ");

                // Check if the line has at least 1 part
                if (parts.length >= 1) {
                    String ageAndSpecies = parts[0];

                    // Get age out of 'ageAndSpecies'
                    String[] theParts = ageAndSpecies.split(" ");

                    Age = Integer.parseInt(theParts[0]);
                    Species = theParts[4].toLowerCase();
                }



                switch (Species) {
                    case "hyena" -> {
                        Name = getName("Hyena", hyenaIndex);
                        hyenaIndex++;
                        Hyena newHyena = new Hyena(Name, Age);
                        animals.add(newHyena);
                        speciesCount.put(Species, speciesCount.getOrDefault(Species, 0) + 1);
                    }
                    case "tiger" -> {
                        Name = getName("Tiger", tigerIndex);
                        tigerIndex++;
                        Tiger newTiger = new Tiger(Name, Age);
                        animals.add(newTiger);
                        speciesCount.put(Species, speciesCount.getOrDefault(Species, 0) + 1);
                    }
                    case "bear" -> {
                        Name = getName("Bear", bearIndex);
                        bearIndex++;
                        Bear newBear = new Bear(Name, Age);
                        animals.add(newBear);
                        speciesCount.put(Species, speciesCount.getOrDefault(Species, 0) + 1);
                    }
                    case null, default -> {
                        Name = getName("Lion", lionIndex);
                        lionIndex++;
                        Lion newLion = new Lion(Name, Age);
                        animals.add(newLion);
                        speciesCount.put(Species, speciesCount.getOrDefault(Species, 0) + 1);
                    }

                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
            e.printStackTrace();
        }

        for (Animal animal : animals) {
            System.out.println("Animal Name: " + animal.getName());
            System.out.println("Animal Age: " + animal.getAge());
            System.out.println("Animal Species: " + animal.getSpecies());
            System.out.println();


        }

        System.out.println("Total Animals: " + Animal.TotalAnimals);

    }

    public static String getName(String name, int index) {
        String returnName = "1";
        String filePath = ("C:/Users/ErikL/OneDrive/Desktop/animalNames.txt");
        File file = new File(filePath);

        try (Scanner scanner = new Scanner(file)) {

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] temp = line.split(" ");

                if (temp[0].equals(name)) {

                    line = scanner.nextLine();
                    line = scanner.nextLine();
                    String[] names = line.split(" ");

                    names[index] = names[index].replace(",", "");
                    returnName = names[index];

                    break; // Exit the loop once the name is found
                }
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("File not found: " + filePath);
            e.printStackTrace();
        }
     return returnName;
    }
}