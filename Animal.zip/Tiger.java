package Pack;

class Tiger extends Animal {
     private int MaxWeight = 660;

    public Tiger(String name, int age) {
        // Assuming 'Tiger' as the default species for this subclass
        super(name, "Tiger",age);
    }

    public int getMaxWeight(){
        return MaxWeight;
    }
}