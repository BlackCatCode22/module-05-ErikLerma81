package Pack;

class Bear extends Animal {
   private int MaxWeight = 1500;

    public Bear(String name, int age) {
        // Assuming 'Bear' as the default species for this subclass
        super(name, "Bear",age);
    }

    public int getMaxWeight(){
        return MaxWeight;
    }
}

